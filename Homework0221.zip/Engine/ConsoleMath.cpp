#include "ConsoleMath.h"

ConsoleMath::ConsoleMath() 
{
}

ConsoleMath::~ConsoleMath() 
{
}

