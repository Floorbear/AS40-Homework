#include "GameBlock.h"

GameBlock::GameBlock() 
{
}

GameBlock::~GameBlock() 
{
}

